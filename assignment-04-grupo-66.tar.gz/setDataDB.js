const express = require('express');
const app = express();

getClient =  require('./searchClient');

const fs = require('fs').promises;

async function listarArquivosDoDiretorio(diretorio) {

    arquivos = []
    let listaDeArquivos = await fs.readdir(diretorio);
    for(let k in listaDeArquivos) {
        let stat = await fs.stat(diretorio + '/' + listaDeArquivos[k]);
        if(stat.isDirectory())
            await listarArquivosDoDiretorio(diretorio + '/' + listaDeArquivos[k], arquivos);
        else
            arquivos.push(diretorio + '/' + listaDeArquivos[k]);
    }

    return arquivos;

}


async function test() {
    let arquivos = await listarArquivosDoDiretorio('./dhbb/text'); 
    return arquivos;
}



async function createData(response,request){
    let arquivos = await test()
    let client = getClient()
    for await (let arq of arquivos){
        client.index({
            index: 'dhbb',
            type: "dhbb_text",
            body: arq
        })
    }
    return response.json({message:"sucesso"})
}

