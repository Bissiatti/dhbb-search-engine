const fs = require('fs');

fs.readFile("./dhbb/text/10.text","utf-8", (err, data) => {
    if (err) throw err;
    console.log(data);
})